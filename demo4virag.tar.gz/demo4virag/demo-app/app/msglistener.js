/*
* Listens to "countchannel" to get message updates. Upon receiving the message,
* the program reads the latest value of counter from Redis (using RedisClient)
* and updates all the web applications by calling io.emit().
*/


module.exports.listen = function(redisSub, redisClient, io) {
  redisSub.subscribe("countchannel");

  redisSub.on("message", function (channel, counterid){
    console.log("Sub channel: "+channel+": "+counterid);
    redisClient.zscore("counterZSet", counterid, function(err, value){
        if(err){
          throw err;
        }else{
          console.log("Counter: "+value);
          io.emit(counterid, value);
        }
      });
  });
};
